import React from "react";
import { AllBarAfter } from "./BarGraph";

export default function App() {
  return (
    <div>
      <AllBarAfter />
    </div>
  );
}