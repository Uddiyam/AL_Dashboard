import React from "react";
import KoreaMap from "./KoreaMap";

export default function Incheon() {
  return <KoreaMap />;
}
