import React from "react";
import KoreaMap from "./KoreaMap";

export default function Jeju() {
  return <KoreaMap />;
}
