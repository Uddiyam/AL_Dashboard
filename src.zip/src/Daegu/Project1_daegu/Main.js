import React from "react";
import { DaeguBarAfter } from "./BarGraph";

export default function App() {
  return (
    <div>
      <DaeguBarAfter />
    </div>
  );
}