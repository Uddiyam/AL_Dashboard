import * as d3 from "d3";
import React, { Component } from "react";
import input_data from "./서울.csv";

class SeoulSearch extends React.Component {
  componentDidMount() {
    this.barChart();
  }
  render() {
    return (
      <div>
        <div id="my_dataviz"></div>
      </div>
    );
  }
  barChart() {
    const margin = { top: 30, right: 30, bottom: 70, left: 70 },
      width = 360 - margin.left - margin.right,
      height = 400 - margin.top - margin.bottom;

    // append the svg object to the body of the page
    const svg = d3
      .select("#my_dataviz")
      .append("svg")
      .attr("width", width + margin.left + margin.right)
      .attr("height", height + margin.top + margin.bottom)
      .append("g")
      .attr("transform", `translate(${margin.left},${margin.top})`);

    // Initialize the X axis
    const x = d3.scaleBand().range([0, width]).padding(0.4);
    const xAxis = svg.append("g").attr("transform", `translate(0,${height})`);

    // Initialize the Y axis
    const y = d3.scaleLinear().range([height, 0]);
    const yAxis = svg.append("g").attr("class", "myYaxis");

    // A function that create / update the plot for a given variable:
    function update(selectedVar) {
      // Parse the Data
      d3.csv(input_data).then(function (data) {
        // X axis
        x.domain(data.map((d) => d.time));
        xAxis.transition().duration(1000).call(d3.axisBottom(x));

        // Add Y axis
        y.domain([0, d3.max(data, (d) => +d[selectedVar])]);
        yAxis.transition().duration(1000).call(d3.axisLeft(y));

        const u = svg.selectAll("rect").data(data);

        // update bars
        u.join("rect")
          .transition()
          .duration(1000)
          .attr("x", (d) => x(d.time))
          .attr("y", (d) => y(d[selectedVar]))
          .attr("width", x.bandwidth())
          .attr("height", (d) => height - y(d[selectedVar]))
          //.style("fill", function(d){ if(d.time=='코로나 전'){return "#DF3A01"} else {return "#A4A4A4"}}); //코로나 전일때
          .style("fill", function (d) {
            if (d.time == "코로나 전") {
              return "#A4A4A4";
            } else {
              return "#084B8A";
            }
          }); //코로나 후일때
      });
    }

    update(check);
  }
}

export default SeoulSearch;
