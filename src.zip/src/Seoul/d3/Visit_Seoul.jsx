import React from "react";
import Bar from "./Bar";
import SeoulVisit from "./SeoulVisit";
import TopList from "../table/TopList";
import "../visit.css";

function Seoul() {
  let check = "after";

  const onClick = () => {
    check = "before";
    console.log(check);
  };

  const onClick2 = () => {
    check = "after";
    console.log(check);
  };

  return (
    <div>
      <div>
        <button onClick={onClick}>코로나 전</button>
        <button onClick={onClick2}>코로나 후</button>
      </div>
      <div className="grap">
        <Bar check={check} />
      </div>
      <div className="grap">
        <SeoulVisit />
      </div>
      <div className="box">
        <TopList />
      </div>
    </div>
  );
}

export default Seoul;
