import KoreaMap from "../KoreaMap";
import Line_seoul from "./Line_seoul";
import Bar from "./d3/Bar";
import SeoulVisit from "./d3/SeoulVisit";
import TopList from "./table/TopList";
import "./seoul.css";
import { D3BarGraph } from "./BarGraph";
import Line from "./Project3/line";
import React, { useRef, useEffect, useState } from "react";
import SeoulLine from "./SeoulLine";

export default function Seoul() {
  return (
    <>
      <KoreaMap />
      <div className="days">
        <D3BarGraph />
      </div>
      <div className="time">
        {" "}
        <Line />
      </div>
      <div className="grap_wrap">
        <div class="grap">
          <Bar />
        </div>
        <div class="grap">
          <SeoulVisit />
        </div>
        <div class="box">
          <TopList />
        </div>
      </div>
      <Line_seoul />
      <SeoulLine />
    </>
  );
}
