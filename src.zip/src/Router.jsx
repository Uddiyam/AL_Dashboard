import { HashRouter as Router, Route, Routes } from "react-router-dom";
import Busan from "./Busan";
import KoreaMap from "./KoreaMap";
import Seoul from "./Seoul/Seoul";
import Daegu from "./Daegu";
import Gangwon from "./Gangwon";
import Gyeonggi from "./Gyeonggi";
import Incheon from "./Incheon";
import Jeju from "./Jeju";
import KoreaAll from "./KoreaAll";

export default function AppRouter() {
  return (
    <>
      <Router>
        <Routes>
          <>
            <Route exact path="/" element={<KoreaAll />} />
            <Route exact path="/Seoul" element={<Seoul />} />
            <Route exact path="/Busan" element={<Busan />} />
            <Route exact path="/Daegu" element={<Daegu />} />
            <Route exact path="/Gangwon" element={<Gangwon />} />
            <Route exact path="/Gyeonggi" element={<Gyeonggi />} />
            <Route exact path="/Incheon" element={<Incheon />} />
            <Route exact path="/Jeju" element={<Jeju />} />
          </>
        </Routes>
      </Router>
    </>
  );
}
